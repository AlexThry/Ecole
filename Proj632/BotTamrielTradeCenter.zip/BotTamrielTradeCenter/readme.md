Ajouter le tri par ordre alphabétique si possible
ajouter les infos de sale dans la bdd
ajouter la date 